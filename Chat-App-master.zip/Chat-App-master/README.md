# ChaApp

Create a complete Chat App similar to WhatsApp, using the MERN stack, packed with all the features you need.

### Hosted Link ->> [ChatApp](https://chat-app-frontend-nine-jet.vercel.app/)
## Project Acritecture
![Screenshot 2024-06-01 105806](https://github.com/Sujitmaurya123/Chat-App/assets/113910576/7b037c80-b2cf-4d33-9c69-d45c0098bc22)

![Screenshot 2024-06-02 125809](https://github.com/Sujitmaurya123/Chat-App/assets/113910576/4271430b-242f-489f-aed3-8d86e4279e98)

![Screenshot 2024-06-01 103301](https://github.com/Sujitmaurya123/Chat-App/assets/113910576/7ec7b56e-ddae-4826-9221-a7f63dead36d)

![Screenshot 2024-06-02 125825](https://github.com/Sujitmaurya123/Chat-App/assets/113910576/416005e9-c3b9-4838-9b34-fb875a50ca98)

![Screenshot 2024-06-02 130058](https://github.com/Sujitmaurya123/Chat-App/assets/113910576/53bd2950-f852-44ae-af7c-aa263a685c10)
---
# Features

1.Real-Time Messaging
2.User Authentication
3.Notifications
4.UI/UX Design
5.Create Groups and Manage groups
6.Admin Dashboard for all see messages ,chats ,user etc.
7. Send Files ,video ,images users to each others
8. Searching Friends and Send Request and chats us.
9. Delete Chats
10. Full responsiveness all devices and Deployment project
***
# Open a web browser and go to https://chat-app-frontend-nine-jet.vercel.app 


# License

This project is licensed under the MIT License.
