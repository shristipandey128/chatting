

export const server = import.meta.env.VITE_SERVER;



// Not Found Page



